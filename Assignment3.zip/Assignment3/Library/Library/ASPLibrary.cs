﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Library
{
    public class ASPLibrary
    {
        LINQtoSQLDataContext data = new LINQtoSQLDataContext();

        public IQueryable<string> GetQuestions()
        {
            var q = from ques in data.TestQuestionsTables select ques.Question;
            return q;
        }

        // Method that adds questions to the database:
        public void AddQuestion(int ID, string question, string optA, string optB, string optC, string optD, string answer)
        {
            TestQuestionsTable test = new TestQuestionsTable();
            test.QuestionID = ID;
            test.Question = question;
            test.PossibleAnswerA = optA;
            test.PossibleAnswerB = optB;
            test.PossibleAnswerC = optC;
            test.PossibleAnswerD = optD;
            test.CorrectAnswer = answer;

            // Adds questions upon submission:
            data.TestQuestionsTables.InsertOnSubmit(test);

            // Saves changes:
            data.SubmitChanges();
        }

        // Method that deletes a specific question in the database:
        public void DeleteQuestion(int ID)
        {
            TestQuestionsTable existing = data.TestQuestionsTables.FirstOrDefault(q => q.QuestionID == ID);
            data.TestQuestionsTables.DeleteOnSubmit(existing);
            data.SubmitChanges();
        }

        // Method that updates an existing question in the database:
        public void UpdateQuestion(int ID, string newanswer)
        {
            TestQuestionsTable existingQuestion = data.TestQuestionsTables.FirstOrDefault(q => q.QuestionID == ID);
            existingQuestion.CorrectAnswer = newanswer;
            data.SubmitChanges();
        }
    }
}
