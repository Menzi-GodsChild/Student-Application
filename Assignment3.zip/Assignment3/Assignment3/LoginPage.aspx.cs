﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using Library;

namespace Assignment3
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        // LINQ to SQL data context:
        LINQtoSQLDataContext data = new LINQtoSQLDataContext();

        public List<LecturerTable> SearchLecturer(string name)
        {
            // ArrayList that reads Lecturer details:
            List<LecturerTable> list = new List<LecturerTable>();
            LecturerTable existingLecturer = data.LecturerTables.FirstOrDefault(q => q.LecturerID == name);
            list.Add(existingLecturer);
            return list;
        }

        public List<StudentTable> SearchStudent(string username)
        {
            // ArrayList that reads Student details:
            List<StudentTable> lists = new List<StudentTable>();
            StudentTable existingStudent = data.StudentTables.FirstOrDefault(a => a.StudentNumber.ToString() == username);
            lists.Add(existingStudent);
            return lists;
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            // Button for Register web form:
            Response.Redirect("http://localhost:52713/RegistrationPage.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            // Grants access for the Student based on their details stored in the database:
            foreach (var items in SearchStudent(tboxUsername.Text))
            {
                if (dropdownRole.SelectedIndex == 1)
                {
                    if (tboxUsername.Text == items.StudentNumber.ToString() && tboxPassword.Text == items.Password)
                    {
                        Response.Redirect("http://localhost:52713/StudentPage.aspx");
                    }

                }
                else
                {
                    // Grants access for the Lecturer based on their details stored in the database:
                    foreach (var item in SearchLecturer(tboxUsername.Text))
                    {
                        if (dropdownRole.SelectedIndex == 0)
                        {
                            if (tboxUsername.Text == item.LecturerID && tboxPassword.Text == item.Password)
                            {
                                Response.Redirect("http://localhost:52713/LecturerPage.aspx");
                            }

                        }
                        else
                        {
                            
                        }
                    }
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            // Button closes the application:
            //Response.Write("<script language='javascript'> {window.close();},</script>");
            Environment.Exit(0);
        }

    }
}