﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using Library;

namespace Assignment3
{
    public partial class DisplayQuestions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LINQtoSQLDataContext data = new LINQtoSQLDataContext();
            List<TestQuestionsTable> testQuestions = (from q in data.TestQuestionsTables select q).ToList();
            gridviewQuestions.DataSource = testQuestions;
            gridviewQuestions.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}