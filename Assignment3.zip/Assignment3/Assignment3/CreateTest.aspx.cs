﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using Library;

namespace Assignment3
{
    public partial class CreateTest : System.Web.UI.Page
    {
        ASPLibrary library = new ASPLibrary();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAddQuestion_Click(object sender, EventArgs e)
        {
            library.AddQuestion(Convert.ToInt32(listQuestionID.Text), tboxQuestion.Text, tboxOptionA.Text, tboxOptionB.Text, tboxOptionC.Text, tboxOptionD.Text, tboxCorrectAnswer.Text);
        }

        protected void btnUpdateQuestion_Click(object sender, EventArgs e)
        {
            library.DeleteQuestion(Convert.ToInt32(listQuestionID.Text));
        }

        protected void btnDeleteQuestion_Click(object sender, EventArgs e)
        {
            library.UpdateQuestion(Convert.ToInt32(listQuestionID.Text), tboxCorrectAnswer.Text);
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            // Button closes the application:
            Response.Write("<script language='javascript'> {window.close();},</script>");
        }
    }
}